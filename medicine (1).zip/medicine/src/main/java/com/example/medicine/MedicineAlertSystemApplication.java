package com.example.medicine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicineAlertSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicineAlertSystemApplication.class, args);
	}

}
